import React from 'react';
import { MapBackground } from './components/MapBackground';
import { ChatInterface } from './components/ChatInterface';
import { useGeolocation } from './hooks/useGeolocation';

const App: React.FC = () => {
  const location = useGeolocation();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-gray-100 relative">
      {/* Map Background Layer */}
      <div className="absolute inset-0 z-0">
        <MapBackground location={location} />
      </div>

      {/* Content Layer */}
      <div className="relative z-10 h-full w-full pointer-events-none flex">
        {/* 
          Chat Interface 
          pointer-events-auto ensures interactions work on the chat 
          while clicking outside passes through to the map 
        */}
        <div className="pointer-events-auto h-full shadow-2xl">
          <ChatInterface location={location} />
        </div>

        {/* 
          Map Controls Placeholder 
          In a full app, we might put floating map buttons here 
        */}
        <div className="flex-1 pointer-events-none"></div>
      </div>
    </div>
  );
};

export default App;