export enum ModelType {
  FLASH_MAPS = 'gemini-2.5-flash',
  PRO_CHAT = 'gemini-3-pro-preview'
}

export interface UserLocation {
  lat: number;
  lng: number;
  error?: string;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
  maps?: {
    uri: string;
    title: string;
    source: string;
    placeAnswerSources?: {
      reviewSnippets?: {
        reviewText: string;
        url: string;
      }[];
    }[];
  };
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isError?: boolean;
  groundingChunks?: GroundingChunk[];
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  model: ModelType;
}