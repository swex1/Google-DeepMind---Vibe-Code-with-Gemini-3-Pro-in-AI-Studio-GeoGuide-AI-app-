import { ModelType } from './types';

export const DEFAULT_LOCATION = {
  lat: 37.7749, // San Francisco
  lng: -122.4194
};

export const MODEL_CONFIGS = {
  [ModelType.FLASH_MAPS]: {
    label: 'Maps Agent (Flash 2.5)',
    description: 'Best for location queries, places, and real-time map data.',
    supportsMaps: true
  },
  [ModelType.PRO_CHAT]: {
    label: 'Reasoning Agent (Pro 3)',
    description: 'Best for complex reasoning, creative writing, and deep analysis.',
    supportsMaps: false // Pro maps support can be variable, safer to disable for strict "Map Agent" distinction
  }
};