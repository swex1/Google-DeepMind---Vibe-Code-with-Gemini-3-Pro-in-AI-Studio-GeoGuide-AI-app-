import React, { useState, useRef, useEffect } from 'react';
import { Send, Map as MapIcon, Sparkles, Navigation, Bot } from 'lucide-react';
import { Message, ChatState, ModelType, UserLocation } from '../types';
import { sendMessageToGemini } from '../services/geminiService';
import { MessageBubble } from './MessageBubble';
import { MODEL_CONFIGS } from '../constants';

interface ChatInterfaceProps {
  location: UserLocation;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ location }) => {
  const [input, setInput] = useState('');
  const [chatState, setChatState] = useState<ChatState>({
    messages: [
      {
        id: 'welcome',
        role: 'model',
        text: "👋 Hi! I'm GeoGuide. I can help you find places nearby using Google Maps data, or answer general questions using Google Search. Try asking: **'Find reliable Italian restaurants near me'**",
        timestamp: new Date()
      }
    ],
    isLoading: false,
    model: ModelType.FLASH_MAPS
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatState.messages]);

  const handleSend = async () => {
    if (!input.trim() || chatState.isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setChatState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isLoading: true
    }));
    setInput('');

    try {
      // Format history for the API
      const history = chatState.messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const response = await sendMessageToGemini({
        message: userMessage.text,
        history,
        location,
        model: chatState.model
      });

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text,
        groundingChunks: response.groundingChunks,
        timestamp: new Date()
      };

      setChatState(prev => ({
        ...prev,
        messages: [...prev.messages, botMessage],
        isLoading: false
      }));

    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "Sorry, I encountered an error connecting to the service. Please try again.",
        isError: true,
        timestamp: new Date()
      };
      
      setChatState(prev => ({
        ...prev,
        messages: [...prev.messages, errorMessage],
        isLoading: false
      }));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleModel = () => {
    setChatState(prev => ({
      ...prev,
      model: prev.model === ModelType.FLASH_MAPS ? ModelType.PRO_CHAT : ModelType.FLASH_MAPS
    }));
  };

  return (
    <div className="flex flex-col h-full bg-white/95 backdrop-blur-md shadow-2xl border-r border-gray-200 w-full md:w-[450px] transition-all duration-300 relative z-10">
      
      {/* Header */}
      <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white/50">
        <div className="flex items-center gap-2 text-indigo-700">
          <MapIcon className="w-6 h-6" />
          <h1 className="font-bold text-xl tracking-tight">GeoGuide AI</h1>
        </div>
        
        {/* Model Switcher */}
        <button 
          onClick={toggleModel}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors text-xs font-medium text-gray-700 border border-gray-200"
          title="Switch AI Model"
        >
          {chatState.model === ModelType.FLASH_MAPS ? (
            <>
              <Navigation size={14} className="text-emerald-500" />
              <span>Flash Maps</span>
            </>
          ) : (
            <>
              <Sparkles size={14} className="text-purple-500" />
              <span>Pro Chat</span>
            </>
          )}
        </button>
      </div>

      {/* Model Info Banner */}
      <div className="bg-gray-50 px-4 py-2 text-xs text-gray-500 border-b border-gray-100">
        {MODEL_CONFIGS[chatState.model].description}
      </div>

      {/* Location Status */}
      {location.error ? (
         <div className="bg-amber-50 px-4 py-2 text-xs text-amber-700 border-b border-amber-100 flex items-center gap-2">
           <span>⚠️ {location.error}</span>
         </div>
      ) : (
        <div className="bg-blue-50/50 px-4 py-1 text-[10px] text-blue-600 border-b border-blue-50 flex items-center justify-end gap-1">
           <Navigation size={10} />
           <span>Located at {location.lat.toFixed(4)}, {location.lng.toFixed(4)}</span>
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/30 scrollbar-thin scrollbar-thumb-gray-200">
        {chatState.messages.map(msg => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        {chatState.isLoading && (
          <div className="flex items-center gap-2 text-gray-400 text-sm p-2 animate-pulse">
            <Bot size={16} />
            <span>GeoGuide is thinking...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-gray-100">
        <div className="relative flex items-end gap-2 p-2 bg-gray-50 border border-gray-200 rounded-xl focus-within:ring-2 focus-within:ring-indigo-100 focus-within:border-indigo-400 transition-all shadow-sm">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={chatState.model === ModelType.FLASH_MAPS ? "Ask about places nearby..." : "Ask me anything..."}
            className="w-full bg-transparent border-none focus:ring-0 resize-none max-h-32 text-sm py-2 px-1 text-gray-700 placeholder-gray-400"
            rows={1}
            style={{ minHeight: '44px' }}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || chatState.isLoading}
            className={`p-2 rounded-lg mb-0.5 transition-all duration-200 ${
              input.trim() && !chatState.isLoading
                ? 'bg-indigo-600 text-white shadow-md hover:bg-indigo-700 hover:scale-105'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            <Send size={18} />
          </button>
        </div>
        <p className="text-[10px] text-gray-400 mt-2 text-center">
          Powered by Google Gemini 2.5 Flash & 3 Pro
        </p>
      </div>
    </div>
  );
};