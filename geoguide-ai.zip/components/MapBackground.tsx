import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { UserLocation } from '../types';

// Fix for default Leaflet markers in React
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Component to update map center when location changes
const MapUpdater: React.FC<{ center: [number, number] }> = ({ center }) => {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, map.getZoom());
  }, [center, map]);
  return null;
};

interface MapBackgroundProps {
  location: UserLocation;
}

export const MapBackground: React.FC<MapBackgroundProps> = ({ location }) => {
  const center: [number, number] = [location.lat, location.lng];

  return (
    <div className="absolute inset-0 z-0 h-full w-full">
      <MapContainer 
        center={center} 
        zoom={14} 
        scrollWheelZoom={true} 
        zoomControl={false} // We can add custom controls if needed
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {/* User Marker */}
        <Marker position={center}>
          <Popup>
            You are here
          </Popup>
        </Marker>

        <MapUpdater center={center} />
      </MapContainer>
    </div>
  );
};