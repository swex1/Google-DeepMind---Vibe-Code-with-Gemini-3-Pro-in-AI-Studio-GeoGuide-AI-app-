import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Bot, User, MapPin, Globe } from 'lucide-react';
import { Message, GroundingChunk } from '../types';

interface MessageBubbleProps {
  message: Message;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  
  const renderGroundingSource = (chunk: GroundingChunk, index: number) => {
    if (chunk.maps) {
      return (
        <a 
          key={index}
          href={chunk.maps.uri}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 p-2 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-sm text-blue-700 transition-colors mb-2"
        >
          <MapPin size={16} />
          <div className="flex flex-col">
            <span className="font-semibold">{chunk.maps.title}</span>
            <span className="text-xs text-blue-600 opacity-80">Google Maps • {chunk.maps.source}</span>
          </div>
        </a>
      );
    }
    if (chunk.web) {
      return (
        <a 
          key={index}
          href={chunk.web.uri}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 p-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-700 transition-colors mb-2"
        >
          <Globe size={16} />
          <div className="flex flex-col">
            <span className="font-semibold">{chunk.web.title}</span>
            <span className="text-xs text-gray-500">Google Search</span>
          </div>
        </a>
      );
    }
    return null;
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'} gap-3`}>
        
        {/* Avatar */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${isUser ? 'bg-indigo-600 text-white' : 'bg-emerald-600 text-white'}`}>
          {isUser ? <User size={18} /> : <Bot size={18} />}
        </div>

        {/* Content */}
        <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
          <div className={`px-4 py-3 rounded-2xl shadow-sm ${
            isUser 
              ? 'bg-indigo-600 text-white rounded-tr-sm' 
              : 'bg-white text-gray-800 border border-gray-100 rounded-tl-sm'
          }`}>
            {message.isError ? (
              <span className="text-red-300">{message.text}</span>
            ) : (
              <div className={`prose prose-sm max-w-none ${isUser ? 'prose-invert' : ''}`}>
                <ReactMarkdown>{message.text}</ReactMarkdown>
              </div>
            )}
          </div>

          {/* Timestamp */}
          <span className="text-xs text-gray-400 mt-1 px-1">
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>

          {/* Grounding Sources (Only for model) */}
          {!isUser && message.groundingChunks && message.groundingChunks.length > 0 && (
            <div className="mt-3 w-full">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Sources</p>
              <div className="flex flex-col gap-1">
                {message.groundingChunks.map((chunk, idx) => renderGroundingSource(chunk, idx))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};