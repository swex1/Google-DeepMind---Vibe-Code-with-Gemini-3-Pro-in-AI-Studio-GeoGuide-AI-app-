import { GoogleGenAI, Tool } from "@google/genai";
import { ModelType, GroundingChunk, UserLocation } from '../types';

// Ensure API key is available
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

interface SendMessageOptions {
  message: string;
  history: { role: string; parts: { text: string }[] }[];
  location: UserLocation | null;
  model: ModelType;
}

export const sendMessageToGemini = async ({
  message,
  history,
  location,
  model
}: SendMessageOptions) => {
  try {
    const isMapsModel = model === ModelType.FLASH_MAPS;

    // Configure tools
    const tools: Tool[] = [];
    
    // Always add Google Search for both models if needed, but definitely for Flash Maps
    tools.push({ googleSearch: {} });

    // Add Google Maps only for the Maps model
    if (isMapsModel) {
      tools.push({ googleMaps: {} });
    }

    const config: any = {
      tools,
      systemInstruction: isMapsModel 
        ? "You are GeoGuide, a location-expert assistant. You have access to the user's real-time location. Use the googleMaps tool to find places, restaurants, and directions near the user. Always provide specific names and addresses when available. If the user asks general questions, use googleSearch."
        : "You are a highly intelligent AI assistant (Gemini 3 Pro). You are helpful, creative, and good at reasoning. Use googleSearch to provide up-to-date information."
    };

    // Add location context if available and using Maps model
    if (isMapsModel && location && !location.error) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: location.lat,
            longitude: location.lng
          }
        }
      };
    }

    // Construct the chat session
    // Note: We recreate the chat session each time for simplicity in this stateless service, 
    // but passing history allows us to maintain context.
    const chat = ai.chats.create({
      model: model,
      config,
      history: history.map(h => ({
        role: h.role,
        parts: h.parts
      }))
    });

    const result = await chat.sendMessage({ message });
    
    const responseText = result.text;
    
    // Safely extract grounding chunks
    // The type definition in the SDK might be loose, so we cast or inspect safely
    const candidates = result.candidates;
    const groundingMetadata = candidates?.[0]?.groundingMetadata;
    const groundingChunks = groundingMetadata?.groundingChunks as GroundingChunk[] | undefined;

    return {
      text: responseText || "I couldn't generate a text response.",
      groundingChunks
    };

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};